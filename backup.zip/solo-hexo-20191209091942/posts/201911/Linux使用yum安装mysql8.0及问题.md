title: Linux使用yum安装mysql8.0及问题
date: '2019-11-22 10:14:33'
updated: '2019-11-22 10:14:33'
tags: [MySQL8]
permalink: /articles/2019/11/22/1574388873885.html
---
![](https://img.hacpai.com/bing/20190317.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

安装配置MySQL 8
	首先我们通过 wget 下载[MySQL官网](https://hacpai.com/forward?goto=https%3A%2F%2Fdev.mysql.com%2Fdownloads%2Frepo%2Fyum%2F)提供的安装包，这里可以直接使用 wget 命令进行下载。
 `` $ wget https://dev.mysql.com/get/mysql80-community-release-el7-3.noarch.rpm``
下载完成后，使用 yum 方式进行安装。yum 命令是 Linux 中的一种安装软件的方式，-y 表示在安装所遇到所有的询问，都默认选择“是”。install 表示安装动作。  
安装 MySQL 命令：
`$ yum -y install mysql80-community-release-el7-3.noarch.rpm`
注册 MySQL 服务命令：  
`$ yum -y install mysql-community-server`  
执行启动服务命令：  
`$ systemctl start mysqld.service`  
此时 MySQL 已经开始运行，但是想要进入 MySQL 需要找出 root 用户随机初始化的密码，通过如下命令可以找出密码：  
`$ grep "password" /var/log/mysqld.log`  
获得的信息为  
`2019-08-12T09:06:30.715432Z 5 [Note] [MY-010454] [Server] A temporary password is generated for root@localhost: FatS0b%vhoM>`  
提取出密码 `FatS0b%vhoM>`  
下面根据 Root 用户名和密码登陆服务（建议直接复制粘贴，自己输入容易输错，Linux 下输入密码时，不会显示出字符，但是实际已经输入，输入完毕后按 Enter 登陆：  
`$ mysql -u root -p`  
此时已经登陆成功，输入一下命令更改初始密码，**切记输入所有 SQL 命令时不要忘记分号，且新密码需要满足：同时包含大小写字母、数字、符号**，将`新密码`替换为你的密码。  
`mysql> ALTER USER 'root'@'localhost' IDENTIFIED BY '新密码';`  
更改完服务密码后，新建一个数据库用户：  
**username**：创建的用户名  
**password**：创建的密码  
**host**：指定该用户在哪个主机上可以登陆，使用通配符`%`  
创建用户命令：  
`mysql> CREATE USER 'username'@'host' IDENTIFIED BY 'password';`  
默认新建用户的加密规则是 caching_sha2_password 方式，有些客户端不支持，所以修改为 mysql_native_password 方式：  
`mysql> alter user 'username'@'host' identified with mysql_native_password by 'password';`  
完成以上操作后推出 MySQL 并重启服务：

mysql> \q // 退出SQL
$ service mysqld restart // 重启SQL服务

  

 `mysql> \q // 退出SQL
$ service mysqld restart // 重启SQL服务` 

重复上面的登陆命令步骤，用新用户登录 MySQL 并手动建库（库名 `solo`，字符集使用 `utf8mb4`，排序规则 `utf8mb4_general_ci`）。  
`CREATE DATABASE` solo `DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;`  
到此，数据库部分已完成。

  

