title: sharding-JDBC学习笔记
date: '2019-11-27 15:48:38'
updated: '2019-11-27 15:51:54'
tags: [sharding-JDBC]
permalink: /articles/2019/11/27/1574840918383.html
---
## ShardingSphere

ShardingSphere 是一套<font color="red">开源</font>的分布式数据库中间件解决方案组成的生态圈，它由**Sharding-JDBC、Sharding-Proxy 和 Sharding-Sidecar**（计划中）这 3 款相互独立的产品组成。 他们均提供**标准化的数据分片、分布式事务和数据库治理功能**，可适用于如 Java 同构、异构语言、容器、云原生等各种多样化的应用场景。

ShardingSphere 定位为关系型数据库中间件，旨在充分合理地在分布式的场景下利用关系型数据库的计算和存储能力，而并非实现一个全新的关系型数据库。 它与 NoSQL 和 NewSQL 是并存而非互斥的关系。NoSQL 和 NewSQL 作为新技术探索的前沿，放眼未来，拥抱变化，是非常值得推荐的。反之，也可以用另一种思路看待问题，放眼未来，关注不变的东西，进而抓住事物本质。 关系型数据库当今依然占有巨大市场，是各个公司核心业务的基石，未来也难于撼动，我们目前阶段更加关注在原有基础上的增量，而非颠覆。

## sharding-jdbc

定位为轻量级 Java 框架，在 Java 的 JDBC 层提供的额外服务。 它使用客户端直连数据库，以 jar 包形式提供服务，无需额外部署和依赖，可理解为增强版的 JDBC 驱动，完全兼容 JDBC 和各种 ORM 框架。

```
适用于任何基于Java的ORM框架，如：JPA, Hibernate, Mybatis, Spring JDBC Template或直接使用JDBC。  
基于任何第三方的数据库连接池，如：DBCP, C3P0, BoneCP, Druid, HikariCP等。  
支持任意实现JDBC规范的数据库。目前支持MySQL，Oracle，SQLServer和PostgreSQL。
```

**功能列表：**

**数据分片**

* 分库 &amp; 分表
* 读写分离
* 分片策略定制化
* 无中心化分布式主键

**分布式事务**

* 标准化事务接口
* XA 强一致事务
* 柔性事务

**数据库治理**

* 配置动态化
* 编排 &amp; 治理
* 数据脱敏
* 可视化链路追踪
* 弹性伸缩(规划中)

## sharding-jdbc 核心概念


 **逻辑表**（LogicTable）：进行水平拆分的时候同一类型（逻辑、数据结构相同）的表的总称。例：订单数据根据主键尾数拆分为10张表，分别是t_order_0到t_order_9，他们的逻辑表名为t_order。  

**真实表**（ActualTable）：在分片的数据库中真实存在的物理表。即上个示例中的t_order_0到t_order_9。

**数据节点**（DataNode）：数据分片的最小单元。由数据源名称和数据表组成，例：ds_0.t_order_0。

**动态表**（DynamicTable）：逻辑表和物理表不一定需要在配置规则中静态配置。如，按照日期分片的场景，物理表的名称随着时间的推移会产生变化。

**绑定表**（BindingTable）：指分片规则一致的主表和子表。例如：t_order表和t_order_item表，均按照order_id分片，则此两张表互为绑定表关系。绑定表之间的多表关联查询不会出现笛卡尔积关联，关联查询效率将大大提升。举例说明，如果SQL为：


```
SELECT i.* FROM t_order o JOIN t_order_item i ON o.order_id=i.order_id WHERE o.order_id in (10, 11);
```

在不配置绑定表关系时，假设分片键 order_id 将数值 10 路由至第 0 片，将数值 11 路由至第 1 片，那么路由后的 SQL 应该为 4 条，它们呈现为笛卡尔积：

`SELECT i.* FROM t_order_0 o JOIN t_order_item_0 i ON o.order_id=i.order_id WHERE o.order_id in (10, 11); `

`SELECT i.* FROM t_order_0 o JOIN t_order_item_1 i ON o.order_id=i.order_id WHERE o.order_id in (10, 11); `

`SELECT i.* FROM t_order_1 o JOIN t_order_item_0 i ON o.order_id=i.order_id WHERE o.order_id in (10, 11); `

`SELECT i.* FROM t_order_1 o JOIN t_order_item_1 i ON o.order_id=i.order_id WHERE o.order_id in (10, 11);`

在配置绑定表关系后，路由的 SQL 应该为 2 条：

```
SELECT i.* FROM t_order_0 o JOIN t_order_item_0 i ON o.order_id=i.order_id WHERE o.order_id in (10, 11); 
```

```
SELECT i.* FROM t_order_1 o JOIN t_order_item_1 i ON o.order_id=i.order_id WHERE o.order_id in (10, 11);
```

其中 t_order 在 FROM 的最左侧，ShardingSphere 将会以它作为整个绑定表的主表。 所有路由计算将会只使用主表的策略，那么 t_order_item 表的分片计算将会使用 t_order 的条件。故绑定表之间的分区键要完全相同。

**广播表**(): 指所有的分片数据源中都存在的表，表结构和表中的数据在每个数据库中均完全一致。适用于数据量不大且需要与海量数据的表进行关联查询的场景，例如：字典表。

**逻辑索引**():某些数据库（如：PostgreSQL）不允许同一个库存在名称相同索引，某些数据库（如：MySQL）则允许只要同一个表中不存在名称相同的索引即可。 逻辑索引用于同一个库不允许出现相同索引名称的分表场景，需要将同库不同表的索引名称改写为`索引名 + 表名`，改写之前的索引名称成为逻辑索引。


**分片键（ShardingColumn)**：分片字段用于将数据库（表）水平拆分的字段，支持单字段及多字段分片。例如上例中的order_id。

**分片算法（ShardingAlgorithm)**：进行水平拆分时采用的算法，分片算法需要应用方开发者自行实现，可实现的灵活度非常高。目前提供4种分片算法。由于分片算法和业务实现紧密相关，因此并未提供内置分片算法，而是通过分片策略将各种场景提炼出来，提供更高层级的抽象，并提供接口让应用开发者自行实现分片算法。


**1、精确分片算法**
对应 PreciseShardingAlgorithm，必选，用于处理使用单一键作为分片键的 = 与 IN 进行分片的场景。需要配合 StandardShardingStrategy 使用。 

**2、范围分片算法**
对应 RangeShardingAlgorithm，可选，用于处理使用单一键作为分片键的 BETWEEN AND 进行分片的场景。
如果不配置 RangeShardingAlgorithm，SQL 中的 BETWEEN AND 将按照全库路由处理。需要配合 StandardShardingStrategy 使用。 

**3、复合分片算法**
对应 ComplexKeysShardingAlgorithm，用于处理使用多键作为分片键进行分片的场景，包含多个分片键的逻辑较复杂，需要应用开发者自行处理其中的复杂度。
需要配合 ComplexShardingStrategy 使用。

**4、Hint  分片算法**
对应 HintShardingAlgorithm，用于处理使用 Hint 行分片的场景。需要配合 HintShardingStrategy 使用。

　　**分片策略（ShardingStrategy）**：包含分片键和分片算法，由于分片算法的独立性，将其独立抽离。真正可用于分片操作的是分片键 + 分片算法，也就是分片策略。目前提供 5 种分片策略。

**1、标准分片策略**
对应 StandardShardingStrategy。提供对 SQL 语句中的 =, IN 和 BETWEEN AND 的分片操作支持。
StandardShardingStrategy 只支持单分片键，提供 PreciseShardingAlgorithm 和 RangeShardingAlgorithm 两个分片算法。
PreciseShardingAlgorithm 是必选的，用于处理 = 和 IN 的分片。
RangeShardingAlgorithm 是可选的，用于处理 BETWEEN AND 分片，如果不配置 RangeShardingAlgorithm，SQL 中的 BETWEEN AND 将按照全库路由处理。 

**2、复合分片策略**
对应 ComplexShardingStrategy。复合分片策略。提供对 SQL 语句中的 =, IN 和 BETWEEN AND 的分片操作支持。
ComplexShardingStrategy 支持多分片键，由于多分片键之间的关系复杂，因此并未进行过多的封装，
而是直接将分片键值组合以及分片操作符透传至分片算法，完全由应用开发者实现，提供最大的灵活度。 

**3、行表达式分片策略**
对应 InlineShardingStrategy。使用 Groovy 的表达式，提供对 SQL 语句中的 = 和 IN 的分片操作支持，只支持单分片键。
对于简单的分片算法，可以通过简单的配置使用，从而避免繁琐的 Java 代码开发，
如: t_user_$-&gt;{u_id % 8} 表示 t_user 表根据 u_id 模 8，而分成 8 张表，表名称为 t_user_0 到 t_user_7。 

**4、Hint 分片策略**
对应 HintShardingStrategy。通过 Hint 而非 SQL 解析的方式分片的策略。 

**5、不分片策略**
对应 NoneShardingStrategy。不分片的策略。



![null](https://img2018.cnblogs.com/blog/1461296/201910/1461296-20191025130136263-933391514.png)

由图可知，在 SQL 执行过程中需要经过几个过程：

例如现在有一条查询语句：

`select * from t_user where id=10；`

进行了分库分表操作，2 个库 ds0，ds1，采用的分片键为 id，逻辑表为 t_user,真实表为 t_user_0、t_user_1 两张表，分库、分表算法为均为取余（%2）。


**sql解析**：通过解析sql语句提取分片键列与值进行分片，例如比较符 =、in 、between and，及查询的表等。 
 
**sql改写**：根据解析结果，及采用的分片逻辑改写sql，上例经过sql改写后，真实语句为：


`select * from t_user_0 where id=10；`


**sql路由**:找到sql需要去哪个库、哪个表执行语句，上例sql根据采用的策略可以得到将在ds0库，t_user_0表执行语句。  

**sql执行**:执行改写后的sql。  

**结果归并**:当我们执行某些复杂语句时，sql可能会在多个库、多个表中执行，sql分别对应执行后会对结果集进行归并操作，得到最终的结果。

