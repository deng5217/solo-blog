title: Windows10系统下忘记MySQL5.7的root密码怎么办?
date: '2019-12-06 11:12:22'
updated: '2019-12-06 11:12:22'
tags: [MySQL]
permalink: /articles/2019/12/06/1575601941975.html
---
在使用MySQL时，需要通过用户名和密码才能登陆。如果忘记了root用户的密码，会给登陆使用带来极大不便。彻底重装MySQL非常繁琐，耗时较长。今天在登陆MySQL时，非常不幸地发现自己忘记了密码，试了几次都失败了，无奈之下只好重新设置root密码。网上常用的重置密码方式都失败了，通过一番检索资料和尝试，将Windows10系统下MySQL5.7版本的忘记登陆密码时，密码重置方式总结如下：
1、关闭MySQL
方法一：以管理员身份运行cmd，停止MySQL服务器
输入命令：net stop mysql
方法二：win+r打开系统服务，停止MySQL服务器
![20190304135753119.png](https://img.hacpai.com/file/2019/12/20190304135753119-1d0ddc7c.png)


2、免密码验证打开MySQL
方法一：mysqld --skip-grant-tables
网上教程常用的方法是利用mysqld --skip-grant-tables命令，按照教程在mysql路径启动cmd执行此命令后，报错了。（如果没有报错直接执行步骤3即可）
![20190304140115156.png](https://img.hacpai.com/file/2019/12/20190304140115156-3ed389a1.png)

方法二：手动修改my.ini配置文件
如果不知道my.ini文件的位置，可以直接在C盘搜索。

![20190304141237771.jpg](https://img.hacpai.com/file/2019/12/20190304141237771-bbb370a3.jpg)


打开my.ini文件，找到[mysqld]字段，在下方添加：skip-grant-tables = true
![20190304140651256.png](https://img.hacpai.com/file/2019/12/20190304140651256-5857a828.png)



保存文件。

3、重启服务
以管理员身份运行cmd，输入命令：net start mysql 重启mysql服务。
![20190304140741423.png](https://img.hacpai.com/file/2019/12/20190304140741423-52fdd69d.png)

4、免密登陆MySQL
输入命令：mysql -uroot
成功登陆MySQL
![20190304140907519.png](https://img.hacpai.com/file/2019/12/20190304140907519-833351d1.png)

5、设置新密码
输入命令：update user set authentication_string=password(“123456”) where user=“root”；
该命令运行结果显示报错。
改为输入命令：update mysql.user set authentication_string=password(‘123456’) where user=‘root’；
成功修改root用户的密码为123456。
![20190304141410975.png](https://img.hacpai.com/file/2019/12/20190304141410975-7c4ad08f.png)


6、刷新
输入命令：flush privileges;
输入命令：exit 退出登录MySQL
![20190304141441591.png](https://img.hacpai.com/file/2019/12/20190304141441591-ab6b5077.png)
7、修改my.ini文件
在验证密码之前，需要将之前修改的my.ini文件还原。
打开my.ini文件，将之前添加的skip-grant-tables = true字段删除，保存文件。

8、验证是否修改my.ini文件成功
输入命令：mysql -uroot
可以发现此时无法免密登陆
![8.png](https://img.hacpai.com/file/2019/12/8-3a458e94.png)

9、验证密码是否修改成功
输入命令：mysql -uroot -p123456
显示成功登陆！
![9.png](https://img.hacpai.com/file/2019/12/9-49d0335b.png)

