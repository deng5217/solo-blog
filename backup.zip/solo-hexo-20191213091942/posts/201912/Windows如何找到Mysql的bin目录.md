title: Windows如何找到Mysql的bin目录
date: '2019-12-06 11:15:18'
updated: '2019-12-06 11:15:18'
tags: [MySQL]
permalink: /articles/2019/12/06/1575602118585.html
---
**点开始>－＞运行，输入 services.msc 在打开的＂服务管理器＂中找到mysql并双击,然后打开属性，如下图，bin找到了，只需要复制目录到环境变量的path下就OK了，然后在cmd中就可以正常进入mysql了**
![20190817223010689.png](https://img.hacpai.com/file/2019/12/20190817223010689-df5791c9.png)

